"""LLM 'senior digitizer' review pass — adds 🟡/🔵 judgment findings the rules miss.

Structured-first, vision-ready: `AIReviewInputs` carries an optional image so a rendered
PNG can be added later without changing the message assembly. LLM findings are always
guided/recommendation (never auto_fix) — the user stays in control.
"""

from __future__ import annotations

import asyncio
import base64
import json
import re
from dataclasses import dataclass
from typing import Any

from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage

from app.core.config import settings
from app.core.logging import logger
from app.core.prompts import load_ai_review_prompt
from app.services.issue_element_mapper import _element_bbox, _union_bbox, _valid_elements
from app.services.llm import llm_service
from app.services.rag import rag_service
from app.services.svg_render import render_svg_to_png

_ALLOWED_CAPS = {"guided", "recommendation"}
_ALLOWED_SEV = {"critical", "high", "medium", "low"}
MAX_FINDINGS = 8


@dataclass
class AIReviewInputs:
    design_report: dict[str, Any]
    fabric: str | None
    rules_payload: dict[str, Any]
    rag_context: str
    image: bytes | None = None  # vision-ready seam; unused until the image upgrade.


def _compact_elements(design_report: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        {
            "id": el.get("id"),
            "stitch_type": el.get("stitch_type"),
            "min_width_mm": el.get("min_dimension_mm"),
            "node_count": el.get("node_count"),
        }
        for el in _valid_elements(design_report)
    ]


def _existing_findings(rules_payload: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        {"id": i.get("id"), "title": i.get("title")}
        for i in (rules_payload.get("issues") or [])
        if isinstance(i, dict)
    ]


def build_review_messages(inputs: AIReviewInputs) -> list[BaseMessage]:
    dr = inputs.design_report
    summary = dr.get("summary") or {}
    structure = dr.get("structure") or {}
    payload = {
        "fabric": inputs.fabric or "unknown",
        "garment": (dr.get("meta") or {}).get("garment_type"),
        "summary": {
            "element_count": summary.get("element_count"),
            "stitch_types": structure.get("stitch_types"),
        },
        "elements": _compact_elements(dr),
        "already_reported": _existing_findings(inputs.rules_payload),
    }
    human = (
        "Design data:\n"
        f"{json.dumps(payload, indent=2, default=str)}\n\n"
        "Relevant documentation:\n"
        f"{inputs.rag_context}\n\n"
        "Return the JSON array of judgment findings now."
    )

    content: Any = human
    if inputs.image is not None:
        # Vision-ready: a provided image is sent as a multimodal content list. The exact
        # block shape is finalized when the image upgrade lands; unused for now.
        b64 = base64.b64encode(inputs.image).decode("ascii")
        content = [
            {"type": "text", "text": human},
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
        ]

    return [
        SystemMessage(content=load_ai_review_prompt()),
        HumanMessage(content=content),
    ]


def _message_text(content: Any) -> str:
    if isinstance(content, list):
        return "".join(
            block.get("text", "") if isinstance(block, dict) else str(block)
            for block in content
        )
    return str(content or "")


def _extract_json_array(text: str) -> list[Any] | None:
    """Extract a JSON array from the LLM output, tolerant of fences and truncation."""
    text = text.strip()
    # Drop a leading ```json / ``` fence and any trailing fence (handles a missing close).
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```\s*$", "", text)
    start = text.find("[")
    if start == -1:
        return None
    body = text[start:]
    try:
        data = json.loads(body)
        if isinstance(data, list):
            return data
    except json.JSONDecodeError:
        pass
    # Salvage a truncated array: keep objects up to the last complete "}".
    last_obj = body.rfind("}")
    if last_obj != -1:
        try:
            data = json.loads(body[: last_obj + 1] + "]")
            if isinstance(data, list):
                return data
        except json.JSONDecodeError:
            pass
    return None


def _focus_bbox(design_report: dict[str, Any], element_ids: list[str]):
    ids = set(element_ids)
    boxes = [_element_bbox(el) for el in _valid_elements(design_report) if el.get("id") in ids]
    return _union_bbox([b for b in boxes if b is not None])


def _sources_from_refs(
    refs: Any, chunks: list[dict[str, Any]] | None
) -> list[dict[str, Any]]:
    """Map the LLM's 1-based [n] chunk references to deduped Source dicts."""
    if not chunks or not isinstance(refs, list):
        return []
    out: list[dict[str, Any]] = []
    seen: set[tuple] = set()
    for ref in refs:
        try:
            idx = int(ref) - 1  # format_context numbers chunks from 1
        except (TypeError, ValueError):
            continue
        if idx < 0 or idx >= len(chunks):
            continue
        meta = chunks[idx].get("metadata") or {}
        # LlamaCloud metadata (e.g. page_label) can be non-string; coerce to str | None so
        # it validates against the Source schema.
        def _s(value: Any) -> str | None:
            return str(value) if value is not None else None

        key = (meta.get("source_file"), meta.get("section_title"))
        if key in seen:
            continue
        seen.add(key)
        out.append(
            {
                "source_file": _s(meta.get("source_file")),
                "source_url": _s(meta.get("source_url")),
                "section_title": _s(meta.get("section_title")),
            }
        )
    return out


def parse_findings(
    text: str,
    design_report: dict[str, Any],
    chunks: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """Robustly parse the LLM JSON into validated issue dicts (source='ai')."""
    raw = _extract_json_array(text)
    if not raw:
        return []
    valid_ids = {str(el.get("id")) for el in _valid_elements(design_report) if el.get("id")}
    findings: list[dict[str, Any]] = []
    for idx, item in enumerate(raw):
        if not isinstance(item, dict):
            continue
        capability = str(item.get("capability", "")).lower().strip()
        if capability not in _ALLOWED_CAPS:
            continue
        title = str(item.get("title") or "").strip()
        if not title:
            continue
        severity = str(item.get("severity", "medium")).lower().strip()
        if severity not in _ALLOWED_SEV:
            severity = "medium"
        try:
            confidence = min(1.0, max(0.0, float(item.get("confidence"))))
        except (TypeError, ValueError):
            confidence = 0.7
        element_ids = [str(x) for x in (item.get("element_ids") or []) if str(x) in valid_ids]
        slug = re.sub(r"[^a-z0-9]+", "_", title.lower()).strip("_")[:32] or "finding"
        findings.append(
            {
                "id": f"ai_{slug}_{idx}",
                "category": "ai",
                "severity": severity,
                "title": title,
                "detail": str(item.get("detail") or "").strip(),
                "suggested_action": str(item.get("suggested_action") or "").strip(),
                "source": "ai",
                "confidence": confidence,
                "capability": capability,
                "element_ids": element_ids,
                "focus_bbox": _focus_bbox(design_report, element_ids) if element_ids else None,
                "fix": None,
                "sources": _sources_from_refs(item.get("source_refs"), chunks),
            }
        )
        if len(findings) >= MAX_FINDINGS:
            break
    return findings


def _review_query(
    design_report: dict[str, Any], fabric: str | None, rules_payload: dict[str, Any]
) -> str:
    structure = design_report.get("structure") or {}
    stitch_types = ", ".join(structure.get("stitch_types") or []) or "embroidery"
    issue_titles = ", ".join(
        str(i.get("title"))
        for i in (rules_payload.get("issues") or [])[:5]
        if isinstance(i, dict) and i.get("title")
    )
    focus = issue_titles or "underlay, density, stitch type choice, small text, satin width"
    return f"embroidery digitizing best practices for {stitch_types} on {fabric or 'fabric'}: {focus}"


async def run_ai_review(
    design_report: dict[str, Any],
    rules_payload: dict[str, Any],
    svg_bytes: bytes | None = None,
) -> list[dict[str, Any]]:
    """Run the LLM review; return validated 🟡/🔵 findings (or [] if no LLM / on failure).

    When `svg_bytes` is given and a renderer is available, a PNG of the design is sent to
    the model so it can also reason about visual issues (small text, layout, aesthetics).
    """
    if not settings.has_llm:
        return []
    fabric = (design_report.get("physical") or {}).get("fabric_type")
    chunks: list[dict[str, Any]] = []
    try:
        rag = await rag_service.retrieve(_review_query(design_report, fabric, rules_payload))
        chunks = rag.chunks
        rag_context = rag_service.format_context(chunks)
    except Exception as exc:  # noqa: BLE001 - RAG is best-effort grounding
        logger.warning("ai_review_rag_failed", error=str(exc))
        rag_context = "No documentation retrieved."

    image: bytes | None = None
    if svg_bytes:
        image = await asyncio.to_thread(render_svg_to_png, svg_bytes)

    inputs = AIReviewInputs(
        design_report=design_report,
        fabric=fabric,
        rules_payload=rules_payload,
        rag_context=rag_context,
        image=image,
    )
    try:
        response = await llm_service.invoke(build_review_messages(inputs))
    except Exception as exc:  # noqa: BLE001 - never let a review failure break the flow
        logger.warning("ai_review_llm_failed", error=str(exc))
        return []
    return parse_findings(_message_text(response.content), design_report, chunks)
